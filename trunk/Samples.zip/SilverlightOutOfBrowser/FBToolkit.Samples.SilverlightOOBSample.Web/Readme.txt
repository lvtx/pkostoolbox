﻿Add xd_receiver.htm and fblogin.js to webproject.
Set id of object tag to _sl_facebookapp.
Include following lines in ap page hosting the object.
    <script src="http://static.ak.connect.facebook.com/js/api_lib/v0.4/FeatureLoader.js.php" type="text/javascript"></script>
    <script type="text/javascript" src="fblogin.js"></script>

Create new app on facebook site and note down the keys. Use these keys in the app.
Set connect url to your website. (eg set it to http://localhost:61274 for this project).
